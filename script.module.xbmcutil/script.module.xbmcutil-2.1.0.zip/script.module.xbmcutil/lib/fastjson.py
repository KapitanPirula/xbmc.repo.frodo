import sys
if sys.version_info >=  (2, 7):	from json import *
else: from simplejson import *