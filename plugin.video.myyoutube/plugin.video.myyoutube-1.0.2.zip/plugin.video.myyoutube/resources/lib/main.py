"""
	Copyright: (c) 2013 William Forde (willforde+xbmc@gmail.com)
	License: GPLv3, see LICENSE for more details
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Call Necessary Imports
from xbmcutil import listitem, plugin, videohostsAPI, storageDB
import threading, os

class Initialize(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Create Data Queues
		plugin["refresh"] = "true"
		self.Queue = __import__("Queue")
		self.queueUrls = self.Queue.Queue()
		self.queueItem = self.Queue.deque()
		plugin["hashd"] = "true"
		
		# For each channel create threaded scraper
		channelNames = self.youtube_channels()
		for channelID in channelNames:
			self.queueUrls.put(channelID)
			threading.Thread(target=self.youtube_scraper).start()
		
		# Wath for queueUrls Queue to be empty
		self.queueUrls.join()
		
		# Convert deque queueItem into normal List of video
		channelVideos = []
		for Gdata in tuple(self.queueItem):
			channelVideos.extend(Gdata.VideoGenerator())
		
		# Set SortMethods and Content
		self.set_sort_methods(self.sort_method_date, self.sort_method_video_runtime, self.sort_method_program_count, self.sort_method_video_rating, self.sort_method_genre, self.sort_method_studio, self.sort_method_video_title)
		self.set_content("episodes")
		
		# Loop Each Listitem and Modify Title with Studio Name
		for _, listitem, isfolder in channelVideos:
			if isfolder is False:
				# Create New Title and ReInitialize Listitem
				listitem.setLabel(u"%s - %s" % (listitem.infoLabels.get("studio",u"Unknown"), listitem.getLabel()))
				listitem.setInfo("video", listitem.infoLabels)
				listitem.addContextMenuItem(plugin.getuni(30101), "XBMC.Container.Update", action="system.videohosts.YTChannelUploads", url=listitem.infoLabels["studio"], hasplaylists=u"true")
				listitem.addContextMenuItems(listitem.contextMenu + listitem._videoMenu, replaceItems=False)
		
		# Return List of Video items
		return channelVideos
	
	def youtube_channels(self):
		# Fetch List of Youtube Channels
		systemData = os.path.join(plugin.getLocalPath(), u"resources", u"data", u"channels.json")
		userData = os.path.join(plugin.getProfile(), u"channels.json")
		if os.path.isfile(systemData) and not os.path.isfile(userData):
			import shutil
			shutil.copy(systemData, userData)
		
		# Return Storage Object
		return storageDB.setStorage(userData)
	
	def youtube_scraper(self):
		# Grab Url from Queue Create Url String
		urlString = u"http://gdata.youtube.com/feeds/api/users/%s/uploads"
		url = urlString % self.queueUrls.get(timeout=600) # TTL 10Min
		
		try:
			# Initialize Gdata API
			Gdata = videohostsAPI.YoutubeAPI(url)
			Gdata.ProcessUrl()
			
			# Store Gdata object for later processing
			self.queueItem.append(Gdata)
		
		finally:
			# Signals to Queue that job is done
			self.queueUrls.task_done()
