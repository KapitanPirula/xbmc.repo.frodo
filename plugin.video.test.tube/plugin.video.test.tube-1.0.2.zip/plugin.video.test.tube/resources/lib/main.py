"""
	Copyright: (c) 2013 William Forde (willforde+xbmc@gmail.com)
	License: GPLv3, see LICENSE for more details
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Call Necessary Imports
from xbmcutil import listitem, urlhandler, storageDB, plugin
from fastjson import load
import base64

# API Key to accsess revision 3
api_key = base64.b64decode(plugin.getuni(30201))
host = base64.b64decode(plugin.getuni(30202))

class Initialize(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		url = u"http://%s/api/getShows.json?api_key=%s" % (host, api_key)
		if "archived" in plugin: url += u"&grouping=archived"
		sourceObj = urlhandler.urlopen(url, 604800) # TTL = 1 Week
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_video_title, self.sort_method_genre)
		self.set_content("files")
		
		# Fetch and Return VideoItems
		return self.json_scraper(sourceObj)
	
	def json_scraper(self, sourceObj):
		# Create Speed vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		limitGenre = plugin.get("showgenre")
		withinArchive = "archived" in plugin
		
		# Decode json object in to memory
		jsonData = load(sourceObj)
		sourceObj.close()
		
		# Add Youtube Channel and Extra Items
		if not (withinArchive or "showgenre" in plugin):
			# Create Fav menu items
			showFav = plugin.getSetting("favorites") == u"true"
			if showFav:
				favObj = FavoritesDB(86400) # TTL = 24 Hours
				favlabel = (plugin.getuni(30101), plugin.getuni(30102))
				favCommand = "XBMC.RunPlugin"
				favParams = {"action":"ModFavorites", "showid":"", "checked":False}
			
			icon = plugin.getIcon()
			self.add_youtube_channel("revision3", hasHD=True)
			self.add_item(u"-%s" % plugin.getuni(30107), thumbnail=(icon,0), url={"archived":"true"})
			self.add_item(u"-%s" % plugin.getuni(30108), thumbnail=(icon,0), url={"action":"ShowEpisodes", "featured":"true"})
			self.add_item(u"-%s" % plugin.getuni(32941), thumbnail=(icon,0), url={"action":"ShowEpisodes", "latest":"true"})
			if showFav and len(favObj) >= 1: self.add_item(u"-%s" % plugin.getuni(30109), thumbnail=(icon,0), url={"action":"Favorites"})
		else:
			showFav = False
		
		# Youtube Context Menu item
		YTLabel = plugin.getuni(32901)
		YTCommand = "XBMC.Container.Update"
		YTParams = {"action":"system.videohosts.YTChannelUploads", "url":None, "hashd":"true"}
		
		# Create New Dict of Show Data and Fetch list of children shows
		import collections
		showData = {}
		childData = collections.defaultdict(list)
		for show in jsonData[u"shows"]:
			showData[show[u"id"]] = show
			if show.get(u"parent_id"):
				childData[show[u"parent_id"]].append(show[u"id"])
		
		# Loop thought earch Show element
		for showid, show in showData.iteritems():
			# If limitGenre is set then limit show selection only to that genre
			if limitGenre and not show["genre"] == limitGenre: continue
			
			# Fetch common var
			genre = show[u"genre"].title()
			
			# Create listitem of Data
			item = localListitem()
			item.setLabel(show[u"name"])
			item.setLabel2(genre)
			item.setInfoDict(genre=genre, plot=show[u"summary"])
			item.setThumbnailImage(show[u"images"][u"logo"])
			item.setParamDict(showid=showid, action="ShowEpisodes", genre=genre)
			
			# Add Menu item to show Catagories
			if withinArchive: item.addContextMenuItem("Category", "XBMC.Container.Update", action="Genre", archived="true")
			else: item.addContextMenuItem(plugin.getuni(21866), "XBMC.Container.Update", action="Genre")
			
			# Add data for child show if available
			if showid in childData:
				urlData = []
				for childID in childData[showid]:
					child = showData[childID]
					urlData.append(plugin.urlencode({"name":u"-"+child[u"name"], "plot":child[u"summary"], "image":child[u"images"][u"logo"], "showid":child[u"id"]}))
				item.setParamDict(extra=",".join(urlData))
			elif show.get(u"parent_id") and show[u"parent_id"] in showData:
				parent = showData[show[u"parent_id"]]
				urlData = plugin.urlencode({"name":u"-"+parent[u"name"], "plot":parent[u"summary"], "image":parent[u"images"][u"logo"], "showid":parent[u"id"]})
				item.setParamDict(extra=urlData)
			
			# Add Youtube Context Menu Item
			if u"youtube_channel" in show:
				YTParams["url"] = show[u"youtube_channel"]
				item.addContextMenuItem(YTLabel, YTCommand, **YTParams)
			
			# Add Fav Context Menu
			if showFav:
				favParams[u"showid"] = showid
				favParams[u"checked"] = favObj.checked(showid)
				item.addContextMenuItem(favlabel[favParams[u"checked"]], favCommand, **favParams)
			
			# Store Listitem data
			additem(item.getListitemTuple(False))
		
		# Return list of listitems
		if showFav: favObj.close()
		return results

class Genre(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		url = u"http://%s/api/getShows.json?api_key=%s" % (host, api_key)
		if "archived" in plugin: url += u"&grouping=archived"
		sourceObj = urlhandler.urlopen(url, 604800) # TTL = 1 Week
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_video_title)
		self.set_content("files")
		
		# Fetch and Return VideoItems
		return self.json_scraper(sourceObj)
	
	def json_scraper(self, sourceObj):
		# Create Speed vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		withinArchive = "archived" in plugin
		
		# Decode json object in to memory
		jsonData = load(sourceObj)
		sourceObj.close()
		
		# Loop thought earch Show element
		for genre in {show[u"genre"] for show in jsonData[u"shows"]}:
			# Create listitem of Data
			item = localListitem()
			item.setLabel(genre.title())
			item.setInfoDict(genre=genre)
			item.setParamDict(showgenre=genre)
			if withinArchive: item.setParamDict(archived="true")
			item.setThumbnailImage("%s.png" % genre, 1)
			
			# Store Listitem data
			additem(item.getListitemTuple(False))
		
		# Return list of listitems
		return results

class ShowEpisodes(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		url = u"http://%s/api/getEpisodes.json?api_key=%s" % (host, api_key)
		if "featured" in plugin: url += u"&grouping=featured"
		elif "latest" in plugin: url += u"&grouping=latest"
		else: url += u"&show_id=%s" % plugin["showid"]
		limit = plugin.getSettingInt("limit")
		offset = (int(plugin.setdefault("nextpagecount", u"1")) -1) * limit
		url += u"&limit=%i&offset=%i" % (limit, offset) 
		sourceObj = urlhandler.urlopen(url, 14400) # TTL = 4 Hours
		self.url = url
		
		# Add Daliy or Parent Show if available
		if "extra" in plugin:
			for extraShow in plugin["extra"].split(u","):
				extraShow = plugin.parse_qs(extraShow)
				self.add_item(extraShow[u"name"], thumbnail=(extraShow[u"image"],0), url={"action":"ShowEpisodes", "showid":extraShow[u"showid"]}, info={"plot":extraShow[u"plot"]})
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_date, self.sort_method_video_runtime, self.sort_method_size, self.sort_method_studio, self.sort_method_video_title)
		self.set_content("episodes")
		
		# Fetch and Return VideoItems
		return self.json_scraper(sourceObj, offset, limit)
	
	def json_scraper(self, sourceObj, offset, limit):
		# Create Speed vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		genre = plugin.get("genre",u"")
		segLabel = plugin.getuni(30106)
		segParams = {"action":"Segments", "url":self.url, "epid":None, "genre":genre}
		quality = plugin.getSettingInt("quality")
		
		# Decode json object in to memory
		jsonData = load(sourceObj)
		showName = "featured" in plugin or "latest" in plugin
		sourceObj.close()
		
		# Check if not in a Feature or latest list
		if not showName and offset < (int(jsonData[u"total"]) - limit):
			# Add Next Page if Needed
			self.add_next_page(url={"showid":plugin["showid"]})
		
		# Loop thought earch Show element
		for episode in jsonData[u"episodes"]:
			# Create listitem of Data
			item = localListitem()
			item.setAudioInfo()
			item.setInfoDict(plot=episode[u"summary"], studio=episode[u"show"][u"name"], episode=episode[u"number"], genre=genre)
			item.setParamDict(action=u"PlayVideo", slug=episode[u"slug"], vidid=episode[u"video_id"])
			item.setDurationInfo(episode[u"duration"])
			item.setThumbnailImage(episode[u"images"][u"medium"])
			
			# Set Quality Overlay and size
			if u"media" in episode:
				media = episode[u"media"]
				if quality == 0 and u"hd720p30" in media: item.setInfoDict(size=media[u"hd720p30"][u"filesize"]); item.setQualityIcon(True)
				elif quality == 0 and u"hd" in media: item.setInfoDict(size=media[u"hd"][u"filesize"]); item.setQualityIcon(True)
				elif quality <=1 and u"large" in media: item.setInfoDict(size=media[u"large"][u"filesize"]); item.setQualityIcon(False)
				elif u"small" in media: item.setInfoDict(size=media[u"small"][u"filesize"]); item.setQualityIcon(False)
				else: item.setQualityIcon(False)
			
			# Add Segments Context Menu if Any Segments exists
			if u"segments" in episode and len(episode[u"segments"]) > 1:
				segParams[u"epid"] = episode[u"id"]
				item.addContextMenuItem(segLabel, "XBMC.Container.Update", **segParams)
			
			# Set Episode Name
			if showName: item.setLabel(u"%s: %s" % (episode[u"show"][u"name"], episode[u"name"]))
			else: item.setLabel(u"%s. %s" % (episode[u"number"], episode[u"name"]))
			
			# Fetch and Filter date
			date = episode[u"published"]
			item.setDateInfo(date[:date.find(u"T")], "%Y-%m-%d")
			
			# Store Listitem data
			additem(item.getListitemTuple(True))
		
		# Return list of listitems
		return results

class Segments(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		sourceObj = urlhandler.urlopen(plugin["url"], 14400) # TTL = 4 Hours
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_video_runtime, self.sort_method_date, self.sort_method_video_title)
		self.set_content("episodes")
		
		# Fetch and Return VideoItems
		return self.json_scraper(sourceObj)
	
	def json_scraper(self, sourceObj):
		# Create Speed vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		selectedShow = plugin["epid"]
		quality = plugin.getSettingInt("quality")
		genre = plugin.get("genre",u"")
		
		# Decode json object in to memory
		jsonData = load(sourceObj)
		sourceObj.close()
		
		# Loop thought earch Show element
		for episode in jsonData[u"episodes"]:
			# Loop untill selected show is found
			if episode[u"id"] == selectedShow:
				# Fetch Common Vars
				image = episode[u"images"][u"medium"]
				params = {"action":u"PlayVideo", "slug":episode[u"slug"], "vidid":episode[u"video_id"]}
				totalTime = episode[u"duration"]
				epNum = episode[u"number"]
				date = episode[u"published"][:episode[u"published"].find(u"T")]
				
				# Set Quality Overlay
				if quality == 0 and u"media" in episode and (u"hd720p30" in episode[u"media"] or u"hd" in episode[u"media"]): isHD = True
				else: isHD = False
				
				# Create listitem for each Segment
				for segment in episode[u"segments"]:
					# Create listitem of Data
					item = localListitem()
					item.setAudioInfo()
					item.setLabel(segment[u"name"])
					item.setThumbnailImage(image)
					item.setParamDict(**params)
					item.setInfoDict(plot=segment[u"summary"], episode=epNum, genre=genre)
					
					# Set Duration and Segment StartPoint
					item.setDurationInfo(segment[u"timecode"])
					item.setResumePoint(segment[u"timecode"], totalTime)
					
					# Set Quality Overlay
					item.setQualityIcon(isHD)
					
					# Fetch and Filter date
					item.setDateInfo(date, "%Y-%m-%d")
			
					# Store Listitem data
					additem(item.getListitemTuple(True))
				
				# Now Break from loop
				break
			
			# Else continue on to net episode until selection is found
			else: continue
		
		# Return list of listitems
		return results

class Favorites(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		url = u"http://%s/api/getEpisodes.json?grouping=latest&api_key=%s&limit=250" % (host, api_key)
		sourceObj = urlhandler.urlopen(url, 14400) # TTL = 4 Hours
		self.url = url
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_date, self.sort_method_video_runtime, self.sort_method_size, self.sort_method_studio, self.sort_method_video_title)
		self.set_content("episodes")
		
		# Fetch and Return VideoItems
		return self.json_scraper(sourceObj)
	
	def json_scraper(self, sourceObj):
		# Create Speed vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		segLabel = plugin.getuni(30106)
		segParams = {"action":u"Segments", u"url":self.url, u"epid":None}
		quality = plugin.getSettingInt("quality")
		
		# Decode json object in to memory
		jsonData = load(sourceObj)
		favObj = FavoritesDB(86400, forceLocal=True) # TTL = 24 Hours
		favlabel = plugin.getuni(30102)
		command = "XBMC.RunPlugin"
		params = {"action":u"ModFavorites", u"showid":"", u"checked":True}
		sourceObj.close()
		
		# Loop thought earch Show element
		for episode in jsonData[u"episodes"]:
			# If show is not checked then continue to next show
			if favObj.checked(episode[u"show_id"]) is False: continue
			
			# Create listitem of Data
			item = localListitem()
			item.setAudioInfo()
			item.setInfoDict(plot=episode[u"summary"], studio=episode[u"show"][u"name"], episode=episode[u"number"])
			item.setParamDict(action=u"PlayVideo", slug=episode[u"slug"], vidid=episode[u"video_id"])
			item.setDurationInfo(episode[u"duration"])
			item.setThumbnailImage(episode[u"images"][u"medium"])
			
			# Set Quality Overlay and size
			if u"media" in episode:
				media = episode[u"media"]
				if quality == 0 and u"hd720p30" in media: item.setInfoDict(size=media[u"hd720p30"][u"filesize"]); item.setQualityIcon(True)
				elif quality == 0 and u"hd" in media: item.setInfoDict(size=media[u"hd"][u"filesize"]); item.setQualityIcon(True)
				elif quality <=1 and u"large" in media: item.setInfoDict(size=media[u"large"][u"filesize"]); item.setQualityIcon(False)
				elif u"small" in media: item.setInfoDict(size=media[u"small"][u"filesize"]); item.setQualityIcon(False)
				else: item.setQualityIcon(False)
			
			# Set Episode Name
			item.setLabel(u"%s: %s" % (episode[u"show"][u"name"], episode[u"name"]))
			
			# Fetch and Filter date
			date = episode[u"published"]
			item.setDateInfo(date[:date.find(u"T")], "%Y-%m-%d")
			
			# Add Fav Remove Context Menu
			params[u"showid"] = episode[u"show_id"]
			item.addContextMenuItem(favlabel, command, **params)
			
			# Add Segments Context Menu if Any Segments exists
			if u"segments" in episode and len(episode[u"segments"]) > 1:
				segParams[u"epid"] = episode[u"id"]
				item.addContextMenuItem(segLabel, "XBMC.Container.Update", **segParams)
			
			# Store Listitem data
			additem(item.getListitemTuple(True))
		
		# Return list of listitems
		favObj.close()
		return results

def ModFavorites():
	favObj = FavoritesDB()
	if plugin["checked"] == u"True": favObj.markNotFavorite(plugin["showid"])
	else: favObj.markFavorite(plugin["showid"])
	plugin.executebuiltin("Container.Refresh")

class FavoritesDB(storageDB.dictStorage):
	def __init__(self, cacheAge=0, forceLocal=False):
		import os
		# Initiate Local Database
		super(FavoritesDB, self).__init__(os.path.join(plugin.getProfile(), u"Favorites.json"))
		
		# Fetch Online Fevorites if Option is Selected
		if plugin.getSettingInt("sync") == 1 and forceLocal is False:
			# Fetch Username and Passwrd
			username = plugin.getSetting("username")
			password = plugin.getSetting("password")
			
			# Fetch Server Data if Username and Password is Valid
			if username and password:
				serverData = self._readServer(cacheAge, username, password)
				if serverData:
					self.update(serverData)
					self.sync()
			elif not username:
				plugin.sendNotification(32807, 30104)
				plugin.setSetting("sync", "0")
			elif not password:
				plugin.sendNotification(32807, 30105)
				plugin.setSetting("sync", "0")
	
	def _readServer(self, cacheAge, username, password):
		# User Acount Details
		accountData = u"email=%s&password=%s&rememberMe=true&submit=login" % (username, password)
		
		# Create Url Handeler
		strHost = host.encode("utf8")
		self.handle = urlhandler.HttpHandler()
		self.handle.add_response_handler()
		self.handle.add_cookie_handler(loginData={"login":"/login", "url":"http://%s/login/auth" % strHost, "data":accountData})
		self.handle.add_cache_handler(cacheAge, asUrl="http://%s/account" % strHost)
		
		# Fetch List of Show ids
		try:
			resp = self.handle.open("http://%s/account" % strHost)
			data = resp.read().decode("utf8")
			resp.close()
		except plugin.URLError:
			# Revort Back to Local Database
			plugin.sendNotification(32807, 30103)
			plugin.setSetting("sync", "0")
			return None
		
		# Filter out Required Data
		import CommonFunctions
		fav = CommonFunctions.parseDOM(data, u"ul", {u"class":u"favoritesList"})
		shows = CommonFunctions.parseDOM(fav, u"li")
		shows.extend(CommonFunctions.parseDOM(fav, u"li", {u"class":u"child"}))
		self.userId = CommonFunctions.parseDOM(data, u"input", {u"type":u"hidden", u"id":u"UserId"}, u"value")[0]
		
		# Filter Favorites
		favData = {}
		for show in shows:
			# Fetch Post Data for Show
			urldata = CommonFunctions.parseDOM(show, u"input", {u"type":u"checkbox"}, u"name")[0]
			# Fetch Show ID
			showid = urldata[urldata.find(u"Shows")+7:]
			if u"_" in showid: showid = showid[:showid.find(u"_")]
			else: showid = showid[:showid.find(u"]")]
			# Check if Show is Selected
			checked = bool(CommonFunctions.parseDOM(show, u"input", {u"checked":u"true"}, u"checked"))
			# Save Show Infomation
			favData[showid] = {u"data":urldata, u"checked":checked}
		
		# Return Dict of Favorites
		return favData
	
	def _saveDatabase(self):
		# Check if Favorites Needs to be Sync Online
		if plugin.getSettingInt("sync") == 1:
			# Create Post Data
			preData = {u"data[User][id]":self.userId}
			for show in self.itervalues():
				if show.get(u"checked") and u"data" in show: preData[show[u"data"]] = u"on"
		
			# Encode PreData into Post Data
			postData = plugin.urlencode(preData)
			self.handle.open(u"http://%s/account/saveFavorites" % host, postData)
		
		# Save Local Database
		self.sync()
		self.close()
	
	def markFavorite(self, showID):
		# Check if Show is already a favorite show
		if showID in self and self[showID].get(u"checked", False): return 
		elif showID in self: self[showID][u"checked"] = True
		else: self[showID] = {u"checked":True}
		self._saveDatabase()
	
	def markNotFavorite(self, showID):
		# Remove identifier from Set and Save
		if showID in self: self[showID][u"checked"] = False
		self._saveDatabase()
	
	def checked(self, showID):
		if showID not in self: return False
		else: return self[showID].get(u"checked", False)

class PlayVideo(listitem.PlayMedia):
	@plugin.error_handler
	def resolve(self):
		# Check if Need to Fetch Video_id
		if not "vidid" in plugin:
			# Create url for oembed api
			url = u"http://%s/api/oembed/?format=json&url=http://%s/%s" % (host, host, plugin["slug"])
			sourceObj = urlhandler.urlopen(url, 57600) # TTL = 16 Hours
			
			# Parse Source
			import re
			jsonObj = load(sourceObj)
			sourceObj.close()
			
			# Fetch HTML Embead Code
			videoCode = re.findall("html5player-v(\d+?)\?", jsonObj[u"html"])
			if videoCode: videoID = videoCode[0]
			else: return None
		else:
			videoID = plugin["vidid"]
		
		# Create url for Video API
		url = u"http://%s/api/getPlaylist.json?codecs=h264&video_id=%s&api_key=%s" % (host, videoID, api_key)
		sourceObj = urlhandler.urlopen(url, 57600) # TTL = 16 Hours
		
		# Parse Source
		items = load(sourceObj)[u"items"]
		sourceObj.close()
		
		# Fetch Quality
		qualityTuple = (u"hd", u"large", u"small", u"ministream")[plugin.getSettingInt("quality"):]
		
		# Check if there is more than one Video to Play
		if len(items) > 1:
			# Serch For Video Url and return Best Quality
			playableData = {"url":[]}
			for item in items:
				h264 = item[u"media"][u"h264"]
				for quality in qualityTuple:
					if quality in h264:
						url = h264[quality][u"url"]
						break
				
				if not url: url = h264.items()[0][1][u"url"]
				playableData["url"].append(url)
				url = None
			
			# Return list of Video to Play
			return playableData
		
		else:
			# Serch For Video Url and return Best Quality
			h264 = items[0][u"media"][u"h264"]
			for quality in qualityTuple:
				if quality in h264:
					return h264[quality]
			
			# Failed to return Preferred Quality, returning default
			return h264.items()[0][1]
