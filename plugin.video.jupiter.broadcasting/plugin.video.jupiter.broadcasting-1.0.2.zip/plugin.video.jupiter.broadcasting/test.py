import sys, os
from hashlib import md5

#print os.getcwd()
#print sys.argv[1]

def worker(filename):
	with open(filename, "rb") as openedfile:
		return openedfile.read()


print md5(worker(sys.argv[1])).hexdigest()

