"""
	Copyright: (c) 2013 William Forde (willforde+xbmc@gmail.com)
	License: GPLv3, see LICENSE for more details
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Call Necessary Imports
from HTMLParser import HTMLParser
from collections import defaultdict

class RssUrlParser(HTMLParser):
	"""
	Parses channel categorys, i.e http://www.jupiterbroadcasting.com/
	"""
	def parse(self, html):
		""" Parses SourceCode and Scrape Video Urls """
		
		# Proceed with parsing
		self.result = defaultdict(lambda: defaultdict(list))
		self.show = False
		self.url = None
		self.feed(html)
		
		# Return Results
		return self.result
	
	def handle_starttag(self, tag, attrs):
		if tag == u"option":
			attrs = dict(attrs)
			if u"value" in attrs and not u"selected" in attrs:
				value = attrs[u"value"]
				if value == u"0" and self.show: self.show = False
				elif value == u"0": self.show = True
				elif value[:4] == u"http" and not u"itunes.apple.com" in value: self.url = value
	
	def handle_data(self, data):
		# If currently on url then add url to dict
		if self.url:
			data = data.lower()
			url = self.url
			self.url = None
			if u"torrent" in data or not self.show: return
			elif u"hd" in data: data = u"720p"
			elif u"video" in data or u"mobile" in data or u"large" in data: data = u"480p"
			elif u"mp3" in data or u"ogg" in data: data = u"audio"
			self.result[self.show][data].append(url)
		
		# If currently on show name then clean and set show name
		elif self.show is True:
			data = data.replace(u"-",u"").strip().title()
			if data == u"Podcast Networks" or data == u"All Shows": self.show = False
			else: self.show = data

class VideoUrlParser(HTMLParser):
	"""
	Parses channel categorys, i.e http://www.jupiterbroadcasting.com/46702/scenic-bgp-route-techsnap-137/
	"""
	def parse(self, html):
		""" Parses SourceCode and Scrape Video Urls """
		
		# Proceed with parsing
		self.results = defaultdict(list)
		self.url = None
		self.feed(html)
		
		# Return Results
		return self.results
	
	def handle_starttag(self, tag, attrs):
		if tag == u"a":
			for name, data in attrs:
				if name == u"href" and ("podtrac.com" in data or "youtube.com" in data):
					self.url = data
					break
	
	def handle_data(self, data):
		if self.url:
			url = self.url
			self.url = None
			ldata = data.lower()
			if u"torrent" in ldata: return
			elif u"hd" in ldata: self.results[u"720p"].append(url)
			elif u"video" in ldata or u"mobile" in ldata: self.results[u"480p"].append(url)
			elif u"mp3" in ldata or u"ogg" in ldata: self.results[u"audio"].append(url)
			elif u"youtube" in ldata: self.results[u"youtube"].append(url)
