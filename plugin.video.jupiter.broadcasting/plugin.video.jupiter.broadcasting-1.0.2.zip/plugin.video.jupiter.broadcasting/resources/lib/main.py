"""
	Copyright: (c) 2013 William Forde (willforde+xbmc@gmail.com)
	License: GPLv3, see LICENSE for more details
	
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# Call Necessary Imports
from xbmcutil import urlhandler, listitem, plugin
import datetime, time

class Initialize(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Jupiter Broadcasting Shows
		url = u"http://www.jupiterbroadcasting.com/"
		sourceCode = urlhandler.urlread(url, 604800, stripEntity=False) # TTL = 1 Week
		
		# Add Youtube Channel and Extra Items
		self.add_youtube_channel(u"jupiterbroadcasting", u"-%s" % plugin.getuni(16100), hasPlaylist=True, hasHD=True)
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_title_ignore_the)
		self.set_content("files")
		
		# Fetch and Return VideoItems
		if plugin.getSettingBool("showschedule"): return self.parser_scraper(sourceCode, self.parse_show_dates())
		else: return self.parser_scraper(sourceCode, {})
	
	def parse_show_dates(self):
		# Call local Import
		import fastjson as json
		import collections
		
		# Fetch Datetime Objects
		self.nowUTC = nowUTC = datetime.datetime.utcnow()
		later = nowUTC + datetime.timedelta(days=15)
		
		# Create urlObj and Add datetime to urlObj
		urlOrg = "https://www.google.com/calendar/feeds/jalb5frk4cunnaedbfemuqbhv4%40group.calendar.google.com/public/embed"
		urlObj = {"ctz":"utc", "singleevents":"true", "max-results":"720", "xsrftok":"V1RDcFVkaVVaVFcwc3JRamhWc3JYMTNGRXBzOjE0MDM0NDg1NzE0MTI", "alt":"json"}
		urlObj["start-min"] = "%sZ" % nowUTC.strftime("%Y-%m-%dT%H:%M:%S")
		urlObj["start-max"] = "%sZ" % later.strftime("%Y-%m-%dT%H:%M:%S")
		url = "%s?%s" % (urlOrg, plugin.urllib.urlencode(urlObj))
		
		# Fetch Google Calendar Data
		handle = urlhandler.HttpHandler()
		handle.add_response_handler()
		handle.add_cache_handler(57600, asUrl=urlOrg)
		sourceObj = handle.open(url)
		jsonData = json.load(sourceObj)["feed"]["entry"]
		jsonData.reverse()
		sourceObj.close()
		
		# Fetch the list of shows with start and end times
		shows = collections.defaultdict(list)
		for show in jsonData:
			title = show["title"]["$t"].lower().replace("live: ","").replace(" ","-")
			shows[title].append(show["gd$when"][0])
		
		# Return list of show and there start and end times
		return shows
	
	def parser_scraper(self, sourceCode, showTimes):
		# Fetch required module
		from parsers import RssUrlParser
		
		# Create Quick Vars
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		quality = [u"720p",u"480p",u"audio"][-(plugin.getSettingInt("quality")+1):]
		
		# Fetch and Convert Timezone to Minutes
		if showTimes:
			timezonePlus = time.altzone < 0
			timeZoneSec = datetime.timedelta(seconds=abs(time.altzone))
			fromtimestamp = datetime.datetime.fromtimestamp
			strptime = localListitem._strptime
			mktime = time.mktime
			nowUTC = self.nowUTC
		
		# Fetch MetaData Database and extract image
		from xbmcutil import storageDB
		metaData = storageDB.Metadata()
		defaultImage = plugin.getIcon()
		
		# Add Live Item
		titleLive = "-%s" % plugin.getuni(30101)
		liz = plugin.xbmcgui.ListItem(titleLive, thumbnailImage=defaultImage)
		liz.setProperty("Fanart_Image", localListitem._fanartImage)
		liz.setProperty("IsPlayable", "true")
		liz.setInfo(type="Video", infoLabels={"title":titleLive})
		self.add_dir_item(("http://videocdn-us.geocdn.scaleengine.net/jblive-iphone/live/jblive.stream/playlist.m3u8", liz, False))
		
		# Pasrse For Each Show
		for show, urls in RssUrlParser().parse(sourceCode).iteritems():
			# Create listitem of Data
			item = localListitem()
			live = "false"
			
			# Fetch StartDate for current show
			showID = show.lower().replace("the","").replace("today","").replace("!","").strip().replace(" ","-")
			if showID in showTimes:
				for times in showTimes[showID]:
					# Fetch StartTime and chack if show has not yet aired
					startTime = fromtimestamp(mktime(strptime(times["startTime"], "%Y-%m-%dT%H:%M:%S.000Z")))
					
					# Check if StartTime is Greater than Current Time
					if startTime > nowUTC:
						# Adjust time to local timezone
						if timezonePlus: startTime += timeZoneSec
						else: startTime -= timeZoneSec
						item.setLabel("%s (Live on %s)" % (show, startTime.strftime("%a, %dth at %H:%M")))
						break
					
					# Fetch Endtime and check if show is still live
					elif nowUTC < fromtimestamp(mktime(strptime(times["endTime"], "%Y-%m-%dT%H:%M:%S.000Z"))):
						item.setLabel("%s ([COLOR red]Live Right Now[/COLOR])" % show)
						live = "true"
						break
			else:
				# Set show title
				item.setLabel(show)
			
			# Fetch url info
			for format in quality:
				if format in urls:
					url = urls[format][0]
					if not url[-11:] == u"?format=xml": url += u"?format=xml"
					item.setParamDict(feed=urls[format][0], action="ShowEpisodes", ishd=str(format==u"720p").lower(), currentlylive=live)
					item.setThumbnailImage(metaData.get(showID,defaultImage))
					item.setIdentifier(showID)
					break
			
			# Store Listitem data
			additem(item.getListitemTuple(False))
		
		# Return list of listitems
		metaData.close()
		return results

class ShowEpisodes(listitem.VirtualFS):
	@plugin.error_handler
	def scraper(self):
		# Fetch List of Revision3 Shows
		sourceObj = urlhandler.urlopen(plugin["feed"], 3600) # TTL = 1 Hour
		
		# Set Content Properties
		self.set_sort_methods(self.sort_method_date, self.sort_method_video_runtime, self.sort_method_size, self.sort_method_episode, self.sort_method_video_title)
		self.set_content("episodes")
		
		# Fetch and Return VideoItems
		return self.xml_scraper(sourceObj)
	
	def xml_scraper(self, sourceObj):
		# Import ElementTree Libaray
		import xml.etree.ElementTree as ElementTree
		results = []
		additem = results.append
		localListitem = listitem.ListItem
		stripTags = urlhandler.strip_tags
		quality = plugin.getSettingInt("quality")
		showID = plugin.get("identifier")
		isHD = quality == 2
		moreAddvanced = isHD and plugin["ishd"] == u"false"
		
		# Parse XML Data into ElementTree and setup NameSpaces
		tree = ElementTree.parse(sourceObj)
		itunes = u"http://www.itunes.com/dtds/podcast-1.0.dtd"
		media = u"http://search.yahoo.com/mrss/"
		sourceObj.close()
		
		# Default Image
		defaultImage = plugin.getIcon()
		showImage = None
		
		# Show Link to Live Stream whan currently live
		if plugin["currentlylive"] == "true":
			# Add Live Item
			titleLive = "[COLOR red]-%s[/COLOR]" % plugin.getuni(30101)
			liz = plugin.xbmcgui.ListItem(titleLive, thumbnailImage=defaultImage)
			liz.setProperty("Fanart_Image", localListitem._fanartImage)
			liz.setProperty("IsPlayable", "true")
			liz.setInfo(type="Video", infoLabels={"title":titleLive, "date":localListitem._strftime("%d.%m.%Y", time.gmtime())})
			self.add_dir_item(("http://videocdn-us.geocdn.scaleengine.net/jblive-iphone/live/jblive.stream/playlist.m3u8", liz, False))
		
		# Loop thought earch Show element
		for node in tree.getiterator(u"item"):
			# Fetch url info
			urlData = node.find(u"enclosure")
			if urlData is None: continue
			
			# Create listitem of Data
			item = localListitem()
			tilte = node.findtext(u"title")
			item.setLabel(tilte)
			
			# Atempt to Fetch Episode Number
			endSect = tilte.rsplit(u" ", 1)[-1].lower().replace(u"s",u"").replace(u"e",u"")
			if endSect.isdigit(): item.setInfoDict("episode", endSect)
			
			# Set Media Flags
			if quality == 0: item.setAudioInfo(codec="mp3")
			else:
				item.setQualityIcon(isHD)
				item.setAudioInfo()
			
			# Fetch Image
			try: thumb = node.find(u"{%s}thumbnail" % media).get(u"url")
			except: thumb = defaultImage
			else:
				if not showImage: showImage = thumb
			item.setThumbnailImage(thumb)
			
			# Fetch Duration
			duration = node.findtext(u"{%s}duration" % itunes)
			if duration: item.setDurationInfo(duration)
			
			# Fetch link to show page
			if moreAddvanced:
				try: link = node.findtext(u"link")
				except: link = u""
			else: link = u""
			
			# Fetch Plot
			plot = node.findtext(u"description")
			if plot: plot = stripTags(plot)
			else: plot = ""
			
			# Fetch url info
			item.setParamDict(url=link, urlbackup=urlData.get(u"url"), action="PlayVideo")
			item.setInfoDict(plot=plot, size=urlData.get(u"length"))
			item.setMimeType(urlData.get(u"type"))
			
			# # Fetch and Filter date
			date = node.findtext(u"pubDate")
			item.setDateInfo(date[:date.rfind(u" ")], "%a, %d %b %Y %H:%M:%S")
			
			# Store Listitem data
			additem(item.getListitemTuple(True))
		
		# Add Image for Current show to Metadata Database
		if showImage:
			from xbmcutil import storageDB
			with storageDB.Metadata() as metaData:
				metaData[showID] = showImage
				metaData.sync()
		
		# Return list of listitems
		return results

class PlayVideo(listitem.PlayMedia):
	@plugin.error_handler
	def resolve(self):
		if "url" in plugin and plugin["url"]:
			# Import Required Modules
			from CommonFunctions import parseDOM
			from parsers import VideoUrlParser
			
			try:
				plugin._suppressErrors = True
				# Fetch Page Source and filter down
				sourceCode = urlhandler.urlread(plugin["url"], 57600, stripEntity=False) # TTL = 16 Hours
				htmlSegment = parseDOM(sourceCode, u"div", {u"id":u"postcontent"})[0]
				
				# Fetch dict of Urls
				qualSetting = plugin.getSettingInt("quality")
				results = VideoUrlParser().parse(htmlSegment)
				if qualSetting == 2 and not u"720p" in results and u"youtube" in results:
					# Set Youtube Link to be the 720p link
					return self.sources(results[u"youtube"][0], sourcetype="youtube_com")
				
				for quality in [u"720p",u"480p",u"audio"][-(qualSetting+1):]:
					if quality in results: return {"url": results[quality][0]}
			except:
				# Log that video is verting to backup
				plugin.debug("Reverting to Backup Url from Feed")
		
		# Return backup url
		return {"url":plugin["urlbackup"]}
